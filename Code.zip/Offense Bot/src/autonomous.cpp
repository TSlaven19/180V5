#include "main.h"

Motor punch (1, 1);
Motor drive_br (2, 1);
Motor drive_bl (3, 0);
Motor punch_two (5, 0);
Motor drive_fl (7, 0);
Motor intake (8, 0);
Motor angle (9, 0);
Motor drive_fr (10, 1);


void driveStraight (int dist, int speed) {
  drive_fl.move_relative(dist, speed);
  drive_bl.move_relative(dist, speed);
  drive_fr.move_relative(dist, speed);
  drive_br.move_relative(dist, speed);
}

void driveStraight (int speed) {
  drive_fl.move(speed);
  drive_bl.move(speed);
  drive_fr.move(speed);
  drive_br.move(speed);
}

void driveStraightSlave (int dist, int speed, int time) {
  drive_fl.tare_position();
  drive_fr.tare_position();
  drive_fl.move_relative(dist, speed);
  drive_fr.move_relative(dist, speed);
  int counter = 0;
  while (counter < time / 2) {
    drive_bl.move_velocity(drive_fl.get_actual_velocity());
    drive_br.move_velocity(drive_fr.get_actual_velocity());
    delay(2);
    counter++;
  }
  driveStraight(0);
}

void encoderTurn (int dist, int speed) {
  drive_fl.move_relative(-dist, speed);
  drive_bl.move_relative(-dist, speed);
  drive_fr.move_relative(dist, speed);
  drive_br.move_relative(dist, speed);
}

void fire () {
  punch.set_brake_mode(MOTOR_BRAKE_COAST);
  punch_two.set_brake_mode(MOTOR_BRAKE_COAST);
  punch.move_relative(950, 200);
  punch_two.move_relative(950, 200);
}

void printVal () {
  std::string val ("val: ");
  val += drive_fl.get_position();
  lcd::set_text(0, val);
}

void BlueFrontFlagOnly() {
  angle.tare_position();
  drive_fl.tare_position();
  delay(200);
  intake.move(100);
  driveStraightSlave(1800, 75, 2000);
  delay(500);
  driveStraightSlave(-2000, 75, 2000);
  intake.move_relative(-1000, 100);
  encoderTurn(-465, 100);
  delay(500);
  fire();
  delay(1000);
  punch.move(0);
  punch_two.move(0);
  intake.move_relative(4000, 200);
  delay(500);
  angle.move_absolute(-90, 100);
  delay(500);
  fire();
  delay(1000);
  angle.move(0);
  punch.move(0);
  punch_two.move(0);
  encoderTurn(-90, 200);
  delay(800);
  driveStraightSlave(2000, 200, 2000);
  driveStraight(0);
}

void BlueFrontFlagPark() {
  angle.tare_position();
  drive_fl.tare_position();
  delay(200);
  intake.move(100);
  driveStraightSlave(1800, 75, 2000);
  delay(500);
  driveStraightSlave(-2000, 75, 2000);
  intake.move_relative(-1000, 100);
  encoderTurn(-465, 100);
  delay(500);
  fire();
  delay(1000);
  punch.move(0);
  punch_two.move(0);
  intake.move_relative(4000, 200);
  delay(500);
  angle.move_absolute(-90, 100);
  delay(500);
  fire();
  delay(1000);
  angle.move(0);
  punch.move(0);
  punch_two.move(0);
  encoderTurn(-100, 75);
  delay(1000);
  driveStraightSlave(-1000, 80, 2000);
  delay(200);
  encoderTurn(550, 75);
  delay(2000);
  driveStraight(3000, 200);
  delay(4000);
  driveStraight(0);
}

/**
 * Runs the user autonomous code. This function will be started in its own task
 * with the default priority and stack size whenever the robot is enabled via
 * the Field Management System or the VEX Competition Switch in the autonomous
 * mode. Alternatively, this function may be called in initialize or opcontrol
 * for non-competition testing purposes.
 *
 * If the robot is disabled or communications is lost, the autonomous task
 * will be stopped. Re-enabling the robot will restart the task, not re-start it
 * from where it left off.
 */
 void autonomous() {
   BlueFrontFlagPark();
 }
