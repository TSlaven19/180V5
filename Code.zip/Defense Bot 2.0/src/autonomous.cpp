#include "main.h"

Motor drive_bl (1, 0);
Motor drive_br (2, 1);
Motor drive_fl (9, 0);
Motor cata (10, 0);
Motor drive_mr (17, 1);
Motor intake (18, 1);
Motor drive_fr (19, 1);
Motor drive_ml (20, 0);

ADIPort gyro ('C', ADI_LEGACY_GYRO);
int gTarget = 0;

void driveStraight (int dist, int speed) {
        drive_fl.move_relative(dist, speed);
        drive_ml.move_relative(dist, speed);
        drive_bl.move_relative(dist, speed);
        drive_fr.move_relative(dist, speed);
        drive_mr.move_relative(dist, speed);
        drive_br.move_relative(dist, speed);
}

void driveStraight (int speed) {
        drive_fl.move(speed);
        drive_ml.move(speed);
        drive_bl.move(speed);
        drive_fr.move(speed);
        drive_mr.move(speed);
        drive_br.move(speed);
}

void driveStraightSlave (int dist, int speed, int time) {
        drive_fl.tare_position();
        drive_fr.tare_position();
        drive_fl.move_relative(dist, speed);
        drive_fr.move_relative(dist, speed);
        int counter = 0;
        while (counter < time / 2) {
                drive_ml.move_velocity(drive_fl.get_actual_velocity());
                drive_bl.move_velocity(drive_fl.get_actual_velocity());
                drive_mr.move_velocity(drive_fr.get_actual_velocity());
                drive_br.move_velocity(drive_fr.get_actual_velocity());
                delay(2);
                counter++;
        }
        driveStraight(0);
}

void driveStraightGyro (int dist, int speed) {
        drive_fl.tare_position();
        drive_fr.tare_position();
        while (abs((int)drive_fl.get_position()) < abs(dist) - 5) {
                drive_fl.move_velocity(speed - (gyro.get_value() * 0.25));
                drive_fr.move_velocity(speed + (gyro.get_value() * 0.25));
                drive_ml.move_velocity(drive_fl.get_actual_velocity());
                drive_bl.move_velocity(drive_fl.get_actual_velocity());
                drive_mr.move_velocity(drive_fr.get_actual_velocity());
                drive_br.move_velocity(drive_fr.get_actual_velocity());
        }
        driveStraight(0);
}

void encoderTurn (int dist, int speed) {
        drive_fl.move_relative(-dist, speed);
        drive_ml.move_relative(-dist, speed);
        drive_bl.move_relative(-dist, speed);
        drive_fr.move_relative(dist, speed);
        drive_mr.move_relative(dist, speed);
        drive_br.move_relative(dist, speed);
}

void blueFrontFlagsOnly() {
        drive_fl.tare_position();
        delay(200);
        intake.move_velocity(200);
        // driveStraightSlave(2500, 100, 1500);
        driveStraightGyro(2500, 100);
        delay(500);
        // driveStraightSlave(-2200, 100, 1500);
        driveStraightGyro(2900, -100);
        delay(200);
        encoderTurn(-780, 90);
        delay(1400);
        intake.move(0);
        driveStraightSlave(150, 50, 800);
        cata.move_relative(5000, 200);
        delay(400);
        gTarget = gyro.get_value();
        // driveStraightGyro(2600, 100);
        driveStraightSlave(2600, 100, 2000);
        encoderTurn(300, 150);
        delay(500);
        driveStraight(500, 100);
        delay(1000);
        driveStraight(0);
}

void redFrontFlagsOnly() {
        drive_fl.tare_position();
        delay(200);
        intake.move_velocity(200);
        // driveStraightSlave(2500, 100, 1500);
        driveStraightGyro(2500, 100);
        delay(500);
        // driveStraightSlave(-2200, 100, 1500);
        driveStraightGyro(2900, -100);
        delay(200);
        encoderTurn(780, 90);
        delay(1400);
        intake.move(0);
        driveStraightSlave(150, 50, 800);
        cata.move_relative(5000, 200);
        delay(400);
        gTarget = gyro.get_value();
        // driveStraightGyro(2600, 100);
        driveStraightSlave(2600, 100, 2000);
        encoderTurn(-300, 150);
        delay(500);
        driveStraight(500, 100);
        delay(1000);
        driveStraight(0);
}

void blueFrontFlagsPark() {
        drive_fl.tare_position();
        delay(200);
        intake.move_velocity(200);
        // driveStraightSlave(2500, 100, 1500);
        driveStraightGyro(2500, 100);
        delay(500);
        // driveStraightSlave(-2200, 100, 1500);
        driveStraightGyro(2900, -100);
        delay(200);
        encoderTurn(-780, 90);
        delay(1400);
        intake.move(0);
        driveStraightSlave(150, 50, 800);
        cata.move_relative(5000, 200);
        delay(400);
        driveStraightSlave(-1600, 100, 1500);
        encoderTurn(800, 90);
        delay(1000);
        driveStraightSlave(300, 50, 1500);
        driveStraight(3700, 175);
}

void blueFrontFlagsMid() {
        drive_fl.tare_position();
        delay(200);
        intake.move_velocity(100);
        driveStraightSlave(2500, 100, 1500);
        delay(500);
        driveStraightSlave(-2400, 100, 1500);
        delay(200);
        intake.move_velocity(200);
        encoderTurn(-425, 90);
        delay(1400);
        intake.move(-100);
        driveStraightSlave(2000, 100, 2000);
        delay(800);
        cata.move_relative(5000, 200);
        delay(800);
        driveStraightSlave(2000, 200, 2000);
        encoderTurn(-300, 100);
        delay(500);
        driveStraightSlave(1500, 100, 1000);
        driveStraight(0);
        intake.move(0);
}

void Task1(void * ignore) {
        while (true) {
                lcd::print(0,"val: %d", gyro.get_value());
                delay(200);
        }
}

/**
 * Runs the user autonomous code. This function will be started in its own task
 * with the default priority and stack size whenever the robot is enabled via
 * the Field Management System or the VEX Competition Switch in the autonomous
 * mode. Alternatively, this function may be called in initialize or opcontrol
 * for non-competition testing purposes.
 *
 * If the robot is disabled or communications is lost, the autonomous task
 * will be stopped. Re-enabling the robot will restart the task, not re-start it
 * from where it left off.
 */
void autonomous() {
        gyro.set_value(0);
        delay(1000);
        Task runner (Task1, (void*)"GYRO", TASK_PRIORITY_DEFAULT,
                     TASK_STACK_DEPTH_DEFAULT, "Gyro Task");
        redFrontFlagsOnly();
}
